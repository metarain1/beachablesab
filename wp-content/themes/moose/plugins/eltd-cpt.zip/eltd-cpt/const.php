<?php

define('ELATED_CPT_VERSION', '1.0');
define('ELATED_CPT_ABS_PATH', dirname(__FILE__));
define('ELATED_CPT_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELATED_CPT_CPT_PATH', ELATED_CPT_ABS_PATH.'/post-types');